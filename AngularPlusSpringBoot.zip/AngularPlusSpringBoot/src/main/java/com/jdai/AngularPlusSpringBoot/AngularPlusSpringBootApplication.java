package com.jdai.AngularPlusSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularPlusSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularPlusSpringBootApplication.class, args);
	}

}
